import json
from tkinter import *
import requests as requests

root = Tk()
root.geometry("600x400")

def parse(user_name):
    github_api_response = requests.get(url_template.format(user_name))
    body = json.loads(github_api_response.text)
    user = {k: v for k, v in body.items() if k in user_fields}

    with open(output_path, 'w') as f:
        json.dump(user, f, ensure_ascii=False, indent=4, sort_keys=True)

    exit(0)

user_fields = ['company', 'created_at', 'email', 'id', 'name', 'url']
url_template = 'https://api.github.com/users/{}'
output_path = 'C:/Users/dvvvn/Desktop/labs/11/user.json'

Label(root, text='Введите имя пользователя:').pack(anchor=N)
var = StringVar()
Entry(root, textvariable=var).pack(anchor=CENTER)
Button(root, text='Кнопка!', command=lambda: parse(var.get())).pack(anchor=S)
root.mainloop()
